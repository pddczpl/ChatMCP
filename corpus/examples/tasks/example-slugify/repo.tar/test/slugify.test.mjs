import assert from 'node:assert/strict';
import test from 'node:test';
import { slugify } from '../src/slugify.mjs';

test('words become lower case and are joined by hyphens', () => {
  assert.equal(slugify('Hello World'), 'hello-world');
});

test('punctuation is dropped', () => {
  assert.equal(slugify('Ready, set... go!'), 'ready-set-go');
});
