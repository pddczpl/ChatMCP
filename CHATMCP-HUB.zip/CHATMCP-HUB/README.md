# ChatMCP Hub 1.1.0

**Nhập yêu cầu trên localhost, dùng ChatGPT web thông thường để xử lý và để Hub thực thi các công cụ MCP trên máy Windows.** Luồng chính dùng ChatMCP Hub Companion 1.3.0 cùng phiên ChatGPT đã đăng nhập trong trình duyệt. Không cần API key hoặc Sign in with ChatGPT cho ứng dụng; không dùng quota Codex/Work. Các lượt chat vẫn chịu hạn mức và điều kiện của ChatGPT web trên tài khoản của bạn.

## 1. Cấu hình dành cho máy này

| Thành phần | Đường dẫn / địa chỉ |
| --- | --- |
| Thư mục gói Hub | `F:\Personal_Project\Vin\ChatMCP\CHATMCP-HUB` |
| Cloud Harness đã cài | `F:\Personal_Project\Vin\ChatMCP\cloud-harness-mcp` |
| Cấu hình MCP nguồn | `deploy\.generated\mcp-client.proxy.json` trong Cloud Harness |
| Cloud Harness local | `http://127.0.0.1:3100/mcp` |
| MCP proxy | `http://127.0.0.1:3006/mcp` |
| Dashboard và địa chỉ Companion sử dụng | `http://127.0.0.1:3007` |

Cần Windows PowerShell 5.1, Node.js 22.12 trở lên, npm, Docker Desktop và Edge/Chrome có hỗ trợ extension Manifest V3. Node 24.19.0 bạn đã kiểm tra đáp ứng yêu cầu. Hub dùng lại Cloud Harness, cấu hình và thông tin xác thực MCP đã có; đây không phải bộ cài Cloud Harness từ đầu.

## 2. Cài hoặc nâng cấp một lần

### A. Đặt gói và khởi động Hub

1. Nếu Hub bản cũ đang chạy, mở dashboard, **Huỷ tác vụ** nếu cần và chờ dừng, rồi bấm **Tắt Hub**. Nếu cửa sổ proxy cũ `START-MCP-BROWSER.ps1` hoặc lệnh `npx ... --port 3006` còn chạy, nhấn **Ctrl+C trong đúng cửa sổ đó**.
2. Giải nén toàn bộ thư mục `CHATMCP-HUB` vào `F:\Personal_Project\Vin\ChatMCP`. Khi nâng cấp, thay các file của gói tại **cùng đường dẫn cũ**. Không xoá repository dự án hoặc thư mục dữ liệu `deploy\.generated`. Kiểm tra không bị lồng thành `CHATMCP-HUB\CHATMCP-HUB`.
3. Nếu Windows chặn các script tải về với lỗi `not digitally signed`, có thể Unblock ZIP trong **Properties** trước khi giải nén. Hoặc chạy một lần cho các script trong đúng gói vừa giải nén:

```powershell
Get-ChildItem -LiteralPath 'F:\Personal_Project\Vin\ChatMCP\CHATMCP-HUB' -Filter '*.ps1' -File -Recurse | Unblock-File
```

Lệnh này không thay execution policy và không cần terminal Administrator. Nếu máy có chính sách tổ chức bắt buộc chữ ký, cần dùng quy trình ký/cho phép của tổ chức.

4. Trong terminal PowerShell của VS Code hoặc Windows, chạy:

```powershell
& 'F:\Personal_Project\Vin\ChatMCP\CHATMCP-HUB\START-CHATMCP-HUB.cmd'
```

Hub mở `http://127.0.0.1:3007` và trả lại dấu nhắc terminal sau khi tiến trình nền đã khởi tạo. Lần đầu, việc cài dependency và chuẩn bị Docker/MCP có thể cần vài phút; theo dõi các thẻ trạng thái và **Nhật ký hoạt động** trên trang.

### B. Nạp Companion 1.3.0 và ghép trình duyệt

1. Trong chính trình duyệt/profile mà launcher vừa dùng để mở localhost, mở `edge://extensions` hoặc `chrome://extensions`, bật **Developer mode**, chọn **Load unpacked** và chọn đúng thư mục chứa `manifest.json`:

```text
F:\Personal_Project\Vin\ChatMCP\CHATMCP-HUB\extension
```

Nếu đã nạp Companion từ chính thư mục này, bấm **Reload** trên thẻ tiện ích và kiểm tra phiên bản **1.3.0**. Nếu còn bản Companion/Button Fix từ thư mục khác, tắt bản cũ để tránh chạy hai bản. Tải lại các tab ChatGPT sau khi nạp hoặc reload extension.

2. **Tắt MCP SuperAssistant trong trình duyệt dùng Hub.** Trong luồng này, Hub thực thi MCP và Companion vận chuyển tin nhắn. Bật thêm Auto Execute/Auto Insert/Auto Submit của MCP SuperAssistant có thể tạo hai bên cùng thực thi. Phần **MCP SuperAssistant — Kết nối thủ công tuỳ chọn** trên dashboard chỉ dành cho một luồng riêng khi Hub không có tác vụ đang chạy.
3. Trên dashboard, mở **Kết nối ChatGPT web**, bấm **Tạo mã ghép**, rồi **Sao chép mã**.
4. Mở popup **ChatMCP Hub Companion**, dán 8 chữ số vào **Mã ghép lấy trên Hub** và bấm **Ghép và bật**. Nếu mã hết hạn, tạo mã mới trên dashboard. Tiện ích lưu ghép nối để dùng lại; bạn không cần ghép cho mỗi yêu cầu.
5. Trong ChatGPT mở ra, đăng nhập nếu cần và chọn **Chat thông thường**, không chọn Work/Codex. Chọn model bạn muốn dùng trong ChatGPT. Companion không tự đổi model, tài khoản hay hạn mức.

Mã ghép chỉ cấp kết nối giữa Companion và Hub local. Token được tạo sau ghép là **token của Hub**, không phải token ChatGPT. Bạn không phải lấy cookie, mã đăng nhập ChatGPT hay API key để dán vào Hub.

### C. Chọn workspace

Trong **Workspace**, bấm **Chọn thư mục…**, chọn thư mục rồi bấm **Dùng thư mục này**. Hoặc dán đường dẫn:

```text
F:\Personal_Project\Vin\K4-Track4-Day23-PhanDanhDat-02627-Sensor-Fusion-Student
```

Chờ **4/4 dịch vụ sẵn sàng**. Nếu cần, bấm **Khởi động MCP**. Hub kiểm tra Docker, mở Docker Desktop hoặc gọi launcher Cloud Harness hiện có khi cần, cài/dùng lại dependency và kiểm tra các công cụ. Những bước khởi tạo riêng của Docker/Windows vẫn có thể cần bạn xử lý thông báo trên máy.

## 3. Dùng hằng ngày: một lệnh

```powershell
& 'F:\Personal_Project\Vin\ChatMCP\CHATMCP-HUB\START-CHATMCP-HUB.cmd'
```

Lệnh mở lại dashboard và chuẩn bị MCP với workspace đã lưu; nếu Hub đã chạy thì dùng lại instance hiện có. Nhập việc cần làm vào **Bạn muốn làm gì?** và bấm **Chạy yêu cầu**. Companion mở một tab ChatGPT riêng cho tác vụ, gửi yêu cầu và chuyển tiếp kết quả MCP. Bạn không phải soạn JSONL hoặc bấm Run cho từng tool.

Muốn dùng ngay thư mục đang mở trong terminal VS Code:

```powershell
& 'F:\Personal_Project\Vin\ChatMCP\CHATMCP-HUB\START-CHATMCP-HUB.cmd' -ProjectPath .
```

Nếu Cloud Harness ở vị trí khác, thêm `-RepoRoot 'D:\duong-dan\cloud-harness-mcp'`. Giữ dashboard ở cổng **3007**: Companion 1.3.0 chỉ nối địa chỉ cố định này.

Ví dụ yêu cầu cho bài lab:

> Đọc README và các file RULES, RUBRIC, CHECKPOINTS, SUBMISSION, AGENTS hoặc SKILL.md liên quan nếu có. Kiểm tra phần còn thiếu của bài Sensor Fusion, giữ những thay đổi hiện có của tôi, rồi sửa file trong workspace Windows đã chọn. Chạy các kiểm tra mà dự án hướng dẫn. Cuối cùng báo file đã sửa, lệnh đã chạy, kết quả thực tế và phần còn bị chặn.

## 4. Tác vụ chạy nền như thế nào?

- Có thể đóng **dashboard hoặc terminal** sau khi Hub đã chạy nền. **Giữ trình duyệt và tab ChatGPT của tác vụ mở**, máy còn hoạt động và Windows còn đăng nhập. Không gõ thêm nội dung hoặc dùng công cụ khác để sửa cuộc chat đang do Hub xử lý.
- **Đã ghép · chờ trình duyệt** vẫn cho phép xếp hàng yêu cầu. Mở đúng trình duyệt đã cài Companion để tiện ích kết nối. Trạng thái kết nối tiện ích không tự chứng minh ChatGPT đã đăng nhập hoặc còn quota.
- Xem **Tiến độ & kết quả**, chọn tác vụ trong lịch sử, **Mở cuộc chat** hoặc **Tải báo cáo**. Kết quả có số lượt, số lần gọi tool và nhật ký; ChatGPT web không cung cấp số token cho cầu nối này.
- **Huỷ tác vụ** dừng điều phối tiếp theo. Nó không hoàn tác file đã sửa; lệnh đã gửi tới MCP có thể đã có tác dụng. Tác vụ gián đoạn không được tự chạy lại các lệnh ghi chưa rõ kết quả.
- Khi không có tác vụ đang chạy, **Dừng kết nối** dừng MCP do Hub quản lý; **Tắt Hub** dừng Hub cùng các tiến trình con nó sở hữu. Docker Desktop và dịch vụ Cloud Harness dùng chung không bị tắt. Hub không tự đăng ký Windows Startup.

BrowserRunner không đặt giới hạn tổng số lượt hoặc tổng thời gian cho một tác vụ. Timeout của từng lời gọi/transport MCP, giới hạn kích thước tin nhắn/ngữ cảnh, quyền server, tài nguyên máy và hạn mức ChatGPT vẫn áp dụng. Đăng nhập, xác minh, thay đổi giao diện ChatGPT hoặc feature flags có thể cần thao tác thủ công. Nếu báo lỗi hoặc hết lượt, đọc thông báo trong cuộc chat và báo cáo; Hub không đổi tài khoản, chuyển sang API hoặc vượt giới hạn để tiếp tục.

## 5. File, công cụ và phạm vi hỗ trợ

| Phần | Cách Hub sử dụng |
| --- | --- |
| File Windows | Desktop Commander đọc/sửa trực tiếp thư mục đã chọn; thay đổi hiện trong VS Code. Terminal chạy với quyền tài khoản Windows. Phạm vi của file tools không phải sandbox hệ điều hành. |
| Workspace Cloud Harness | Các clone Docker dùng `workspaceId` riêng. Chúng không phải đường dẫn `F:\...` và không tự đồng bộ/bind-mount với thư mục Windows. |
| Toàn bộ tools | Đọc hết danh mục của cả Cloud Harness và Desktop Commander, giữ tên, mô tả và input schema. Xem **Toàn bộ công cụ MCP**, tìm theo tên/tham số hoặc tải JSON. Không dùng một danh sách con cố định. |
| Resources, prompts, skills | Lấy các danh mục mà server công bố; các tool `skills_list`, `skills_read`, `skills_run` và tool khác vẫn có khi upstream cung cấp. Hướng dẫn trong repository được đọc theo yêu cầu tác vụ. |
| Dữ liệu đưa vào ChatGPT | Cầu nối hiện hỗ trợ tin nhắn văn bản/JSON. Chưa tự đính kèm ảnh, audio hoặc file vào ChatGPT. Tool có thể trả byte/binary, nhưng điều đó không có nghĩa model đã nhìn hoặc nghe nội dung đó. |

Đủ danh mục không bảo đảm mọi tool và mọi định dạng đều dùng được trọn vẹn qua giao diện chat. GitHub permissions, network profile, lease, dependency và khả năng upstream vẫn quyết định kết quả. `network-none` trong Docker vẫn giữ nguyên; Hub không tự cấp quyền push hoặc bật mạng. Muốn kết quả từ Docker xuất hiện trên Windows, tác vụ phải chuyển file rõ ràng và kiểm tra file đích.

Hub sao lưu trước khi cập nhật `allowedDirectories` của Desktop Commander theo tài khoản Windows. Cấu hình này có thể được client Desktop Commander khác dùng chung; tránh đổi nó từ client khác trong khi Hub đang chạy tác vụ.

## 6. Dữ liệu được lưu

Thư mục dữ liệu:

```text
F:\Personal_Project\Vin\ChatMCP\cloud-harness-mcp\deploy\.generated\chatmcp-hub
```

| File / thư mục | Nội dung |
| --- | --- |
| `hub-state.json` | Workspace đã chọn |
| `mcp-client.hub.json` | Cấu hình MCP riêng của Hub, có thông tin xác thực upstream |
| `browser\browser-client.json` | Định danh ghép Companion, thời điểm ghép và hash token Hub; không lưu token Hub thô ở file này |
| `browser\tasks\<id>` | `task.json`, `transcript.jsonl`, `report.txt` của từng tác vụ |
| `hub.log` | Nhật ký Hub, che các secret đã nhận diện |

Token Hub thô được Companion lưu trong storage local của extension để kết nối lại. Prompt và phần file/kết quả MCP cần cho tác vụ được gửi vào cuộc chat ChatGPT; nhật ký cũng có thể chứa nội dung dự án. Không chia sẻ nguyên cấu hình hoặc thư mục dữ liệu khi chỉ cần gửi một thông báo lỗi.

Nếu nâng từ bản 1.0, các file model/credential và mã nguồn API/SIWC cũ có thể còn để tham khảo. **Launcher và trang chính 1.1.0 không nạp thông tin xác thực đó hoặc khởi chạy provider API/SIWC.** Không cần cấu hình chúng để dùng bản này.

## 7. Khi chưa chạy được

| Hiện tượng | Cách xử lý |
| --- | --- |
| `not digitally signed` | Unblock script của gói như mục 2, rồi chạy lại launcher. Không đổi execution policy toàn máy. |
| Vẫn thấy giao diện cấu hình API của bản cũ | Huỷ/dừng Hub cũ, bấm **Tắt Hub**, chạy lại launcher mới và tải lại dashboard. Thay file khi daemon cũ còn chạy chưa làm daemon đó đổi phiên bản. |
| Cổng 3006 đang dùng | Ctrl+C trong đúng cửa sổ proxy cũ đã mở, rồi **Khởi động MCP**. Không mở hai launcher proxy cùng lúc. |
| Thiếu cấu hình hoặc MCP chưa sẵn sàng | Kiểm tra cấu hình nguồn hiện có, Docker Desktop và **Nhật ký hoạt động**. Lần cài package đầu cần npm/Internet; một dòng npm notice chưa chứng minh cài thành công. |
| Đã ghép nhưng yêu cầu vẫn chờ | Mở đúng browser/profile có Companion 1.3.0; kiểm tra tiện ích được bật, Hub ở `127.0.0.1:3007`, rồi mở popup và bấm **Cập nhật**. |
| Không hiện mã / mã hết hạn / đổi profile | **Tạo mã ghép** mới trên Hub rồi **Ghép và bật** trong popup. Khi cần ghép lại một kết nối đã lưu, dùng **Huỷ ghép tiện ích** trên Hub trước. |
| ChatGPT yêu cầu đăng nhập, xác minh, báo hết lượt hoặc không nhận diện được ô chat | Mở tab tác vụ và xử lý thông báo. Giữ Chat thông thường. Không liên tục gửi lại prompt hoặc chạy lại lệnh ghi khi kết quả chưa rõ. |
| Browser ngủ, tab bị đóng hoặc Hub dừng giữa tác vụ | Xem trạng thái/báo cáo và kiểm tra file hiện tại trước khi giao việc tiếp. Không coi lỗi transport là bằng chứng file chưa thay đổi. |
| Không mở được hộp chọn thư mục | Dán đường dẫn vào **Workspace** và bấm **Dùng thư mục này**. |

## 8. Kiểm chứng và nguồn

Xem **VALIDATION.txt** để biết phạm vi kiểm thử của bản bàn giao. Trong lần chuẩn bị này, Desktop Commander thật đã được chạy kiểm tra với dữ liệu thử sau khi bạn đồng ý telemetry/feature flags của upstream; giao thức BrowserRunner, HTTP local và các tình huống lỗi được kiểm thử bằng fixture. Chưa xác minh native Windows trên máy bạn hoặc thao tác DOM ChatGPT thật. Các kiểm tra này không phải kết quả chạy bài lab Sensor Fusion.

Trạng thái **Hoàn thành** nghĩa là Hub đã nhận kết quả cuối hợp lệ của model. Đánh giá việc hoàn thành yêu cầu dựa trên file đã thay đổi và kết quả kiểm tra thực tế trong báo cáo; không có cam kết mọi giao diện, tool hoặc tác vụ luôn không lỗi.

- Cloud Harness: <https://github.com/bestagentkits/cloud-harness-mcp>
- Desktop Commander: <https://github.com/wonderwhy-er/DesktopCommanderMCP>
- MCP SuperAssistant/proxy: <https://github.com/srbhptl39/MCP-SuperAssistant>
- MCP SDK: <https://github.com/modelcontextprotocol/typescript-sdk>

Hướng dẫn chi tiết của Companion nằm trong **extension/HUONG-DAN.txt**. Phiên bản dependency và thông báo bên thứ ba nằm trong **THIRD-PARTY-NOTICES.txt**.
