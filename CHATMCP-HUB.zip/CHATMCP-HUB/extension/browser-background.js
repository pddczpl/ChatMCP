(() => {
  'use strict';
  const HUB = 'http://127.0.0.1:3007';
  const PAIR_KEY = 'chatmcpBrowserPairV1';
  const JOURNAL_KEY = 'chatmcpBrowserJournalV1';
  const ALARM = 'chatmcp-browser-poll';
  const TERMINAL = new Set(['completed', 'failed', 'cancelled', 'interrupted', 'limit']);
  const UNCERTAIN = new Set(['claiming', 'claimed', 'sending']);
  const ENDPOINTS = new Set(['pair', 'poll', 'claim', 'sent', 'reply', 'fail']);
  let pair = null, journal = null, lastNote = 'Chưa ghép với Hub.', lastContact = null;
  let ticking = false, epoch = 0, scheduled = null;
  let persistence = Promise.resolve();
  let bootPromise;

  const ownPopup = sender => sender?.id === chrome.runtime.id && !sender.tab && sender.url === chrome.runtime.getURL('popup.html');
  const safeChatUrl = value => {
    try {
      const url = new URL(value);
      return url.origin === 'https://chatgpt.com' && (url.pathname === '/' || /^\/c\/[^/]+\/?$/.test(url.pathname)) ? url.origin + url.pathname : null;
    } catch { return null; }
  };
  const topChat = sender => sender?.id === chrome.runtime.id && sender.frameId === 0 && Number.isInteger(sender.tab?.id) && safeChatUrl(sender.url);
  const topHub = sender => {
    try { const url = new URL(sender.url); return sender.id === chrome.runtime.id && sender.frameId === 0 && Number.isInteger(sender.tab?.id) && url.origin === HUB && url.pathname === '/'; }
    catch { return false; }
  };
  const active = () => journal && !['terminal', 'failed'].includes(journal.phase);
  const uuid = value => typeof value === 'string' && /^[0-9a-f-]{36}$/i.test(value);
  const serialSize = value => new TextEncoder().encode(JSON.stringify(value)).length;

  function persist(work) {
    const pending = persistence.then(work);
    persistence = pending.catch(() => {});
    return pending;
  }
  async function savePair() { const value = structuredClone(pair); await persist(() => chrome.storage.local.set({ [PAIR_KEY]: value })); }
  async function saveJournal() { const value = structuredClone(journal); await persist(() => chrome.storage.local.set({ [JOURNAL_KEY]: value })); }
  const isCurrent = (record, ownEpoch) => ownEpoch === epoch && journal === record;
  async function boot() {
    // Content scripts never receive the Hub capability token, including through
    // chrome.storage. No ChatGPT credential is read, stored or requested.
    await chrome.storage.local.setAccessLevel?.({ accessLevel: 'TRUSTED_CONTEXTS' });
    const saved = await chrome.storage.local.get([PAIR_KEY, JOURNAL_KEY]);
    pair = saved[PAIR_KEY] || null;
    journal = saved[JOURNAL_KEY] || null;
    if (pair && (!uuid(pair.clientId) || typeof pair.token !== 'string' || pair.token.length < 16)) pair = null;
    if (journal && (!uuid(journal.taskId) || typeof journal.messageId !== 'string' || typeof journal.phase !== 'string')) journal = null;
    if (journal && UNCERTAIN.has(journal.phase)) {
      journal.phase = 'failed';
      journal.failurePending = true;
      journal.reason = 'worker_restarted_during_send: Trình duyệt dừng giữa bước nhận/gửi; không tự gửi lại.';
      await saveJournal();
    }
    if (pair) {
      const alarm = await chrome.alarms.get(ALARM);
      if (!alarm) await chrome.alarms.create(ALARM, { delayInMinutes: 0.5, periodInMinutes: 0.5 });
      lastNote = pair.authFailed ? 'Ghép nối không còn hợp lệ. Lấy mã mới trên Hub.' : 'Đã ghép; đang chờ yêu cầu từ localhost.';
    }
  }
  function ready() { return bootPromise ||= boot(); }
  function schedule(ms = 1200) {
    if (scheduled || !pair || pair.authFailed) return;
    scheduled = setTimeout(() => { scheduled = null; void tick(); }, ms);
  }

  async function api(endpoint, body, authentication = pair) {
    if (!ENDPOINTS.has(endpoint)) throw new Error('invalid_endpoint');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (endpoint !== 'pair') {
        if (!authentication?.token || authentication.authFailed) throw new Error('pairing_required');
        headers.Authorization = 'Bearer ' + authentication.token;
        body = { ...body, clientId: authentication.clientId };
      }
      const response = await fetch(HUB + '/api/browser/clients/' + endpoint, {
        method: 'POST', headers, body: JSON.stringify(body), credentials: 'omit', redirect: 'error', cache: 'no-store', signal: controller.signal
      });
      if (!response.ok) throw new Error('hub_http_' + response.status);
      const text = await response.text();
      if (new TextEncoder().encode(text).length > 3 * 1024 * 1024) throw new Error('hub_response_too_large');
      const value = JSON.parse(text);
      lastContact = Date.now();
      return value;
    } finally { clearTimeout(timer); }
  }

  async function toTab(type, extra = {}, record = journal) {
    if (!Number.isInteger(record?.tabId)) throw new Error('owned_tab_missing');
    return chrome.tabs.sendMessage(record.tabId, { type, taskId: record.taskId, messageId: record.messageId, pageId: record.pageId || null, ...extra }, { frameId: 0 });
  }

  async function fail(reason, record = journal, ownEpoch = epoch) {
    if (!record || !isCurrent(record, ownEpoch) || record.phase === 'terminal') return;
    const authentication = pair;
    record.phase = 'failed'; record.reason = String(reason).slice(0, 500); record.failurePending = true;
    delete record.reply;
    lastNote = record.reason;
    await saveJournal();
    if (!isCurrent(record, ownEpoch)) return;
    try { await toTab('CHATMCP_BROWSER_CANCEL', { stopGeneration: false }, record); } catch {}
    if (!isCurrent(record, ownEpoch)) return;
    try {
      await api('fail', { taskId: record.taskId, messageId: record.messageId, reason: record.reason }, authentication);
      if (!isCurrent(record, ownEpoch)) return;
      record.failurePending = false; await saveJournal();
    } catch { /* Retry only the idempotent failure report, never claim/send. */ }
  }

  async function end(status) {
    const record = journal, ownEpoch = epoch;
    if (!record || record.phase === 'terminal') return;
    try { await toTab('CHATMCP_BROWSER_CANCEL', { stopGeneration: status === 'cancelled' }, record); } catch {}
    if (!isCurrent(record, ownEpoch)) return;
    record.phase = 'terminal'; record.status = status; record.failurePending = false;
    delete record.reply;
    await saveJournal();
    lastNote = 'Phiên kết thúc: ' + status + '.';
  }

  async function acknowledgeSent() {
    const record = journal, ownEpoch = epoch;
    if (record.sentAck) return;
    await api('sent', { taskId: record.taskId, messageId: record.messageId, url: record.url });
    if (!isCurrent(record, ownEpoch)) return;
    record.sentAck = true; await saveJournal();
  }
  async function deliverReply() {
    const record = journal, ownEpoch = epoch;
    if (!record.reply) throw new Error('reply_record_missing');
    const result = await api('reply', record.reply);
    if (!isCurrent(record, ownEpoch)) return;
    if (result?.accepted !== true) throw new Error('reply_not_accepted');
    record.phase = 'replied'; delete record.reply; await saveJournal();
    lastNote = 'Đã chuyển câu trả lời về Hub; đang chờ công cụ hoặc bước tiếp theo.';
  }

  async function prepareAndSend(message, instanceId, ownEpoch) {
    if (ownEpoch !== epoch) return;
    if (!journal || journal.taskId !== message.taskId || journal.messageId !== message.id) {
      const sameTask = journal?.taskId === message.taskId;
      if (sameTask && !['replied', 'terminal'].includes(journal.phase)) return;
      journal = { taskId: message.taskId, messageId: message.id, turn: message.turn, phase: 'preparing', tabId: sameTask ? journal.tabId : null, pageId: sameTask ? journal.pageId : null, instanceId, preparedAt: Date.now(), sentAck: false };
      await saveJournal();
    }
    const record = journal;
    const atPhase = phase => isCurrent(record, ownEpoch) && record.phase === phase;
    if (!atPhase('preparing')) return;
    if (!Number.isInteger(record.tabId)) {
      // A new task always starts at an ordinary ChatGPT page. It does not reuse
      // or inspect the user's existing conversations or select an account/model.
      const tab = await chrome.tabs.create({ url: 'https://chatgpt.com/', active: false });
      if (!atPhase('preparing')) return;
      if (!Number.isInteger(tab?.id)) throw new Error('cannot_create_chat_tab');
      record.tabId = tab.id; await saveJournal();
      if (!atPhase('preparing')) return;
    }
    const tab = await chrome.tabs.get(record.tabId);
    if (!atPhase('preparing')) return;
    if (tab.status === 'loading') { lastNote = 'Đang mở tab ChatGPT dành riêng cho tác vụ.'; return; }
    if (!safeChatUrl(tab.url)) { await fail('owned_tab_navigated: Tab đã rời trang ChatGPT của tác vụ.'); return; }
    let prepared;
    try { prepared = await toTab('CHATMCP_BROWSER_PREPARE', { turn: message.turn, text: message.text }, record); }
    catch {
      if (!atPhase('preparing')) return;
      if (Date.now() - record.preparedAt < 45000) { lastNote = 'Đang đợi nội dung ChatGPT nạp xong.'; return; }
      await fail('content_script_unavailable: Tải lại extension/tab và kiểm tra quyền truy cập chatgpt.com.'); return;
    }
    if (!atPhase('preparing')) return;
    if (!prepared?.ok) {
      if (prepared?.retryable && Date.now() - record.preparedAt < 45000) { lastNote = 'Đang đợi ô chat/nút gửi sẵn sàng.'; return; }
      await fail(prepared?.reason || 'unknown_chat_dom'); return;
    }
    if (typeof prepared.pageId !== 'string' || !safeChatUrl(prepared.url)) { await fail('invalid_prepare_response'); return; }
    record.pageId = prepared.pageId;
    // Persist before claiming. If acknowledgement is lost, no worker/tab restart
    // is allowed to re-claim or re-send this message.
    record.phase = 'claiming'; await saveJournal();
    if (!atPhase('claiming')) return;
    let claim;
    try { claim = await api('claim', { taskId: message.taskId, messageId: message.id }); }
    catch { await fail('claim_uncertain: Chưa biết Hub đã nhận bước này hay chưa; không tự gửi lại.', record, ownEpoch); return; }
    if (!atPhase('claiming')) return;
    if (claim?.ok !== true || claim.message?.id !== message.id || claim.message?.taskId !== message.taskId || claim.message?.turn !== message.turn || claim.message?.text !== message.text) { await fail('claim_mismatch: Nội dung đã đổi hoặc bước không còn hợp lệ.'); return; }
    record.phase = 'claimed'; await saveJournal();
    if (!atPhase('claimed')) return;
    record.phase = 'sending'; await saveJournal();
    if (!atPhase('sending')) return;
    let sent;
    try { sent = await toTab('CHATMCP_BROWSER_SEND', {}, record); }
    catch { await fail('send_uncertain: Mất xác nhận sau thao tác gửi; không tự bấm gửi lần nữa.', record, ownEpoch); return; }
    if (!atPhase('sending')) return;
    if (!sent?.ok || sent.pageId !== record.pageId || !safeChatUrl(sent.url)) { await fail(sent?.reason || 'send_unconfirmed'); return; }
    record.phase = 'sent'; record.url = safeChatUrl(sent.url); record.sentAck = false;
    await saveJournal();
    if (!atPhase('sent')) return;
    lastNote = 'Đã gửi vào ChatGPT thông thường; đang đợi câu trả lời.';
    await acknowledgeSent();
  }

  async function tick() {
    await ready();
    if (ticking || !pair || pair.authFailed) return;
    ticking = true;
    const ownEpoch = epoch;
    try {
      const poll = await api('poll', {});
      if (ownEpoch !== epoch) return;
      if (!poll || typeof poll.instanceId !== 'string') throw new Error('invalid_poll_response');
      const task = poll.task;
      if (!task || TERMINAL.has(task.status)) {
        if (journal && (!task || journal.taskId === task.id)) await end(task?.status || 'interrupted');
        return;
      }
      if (!uuid(task.id)) throw new Error('invalid_task');
      if (journal?.taskId === task.id && journal.instanceId !== poll.instanceId && active()) { await fail('hub_restarted: Phiên Hub đã thay đổi; không tự gửi lại bước cũ.'); return; }
      if (journal?.taskId === task.id && journal.phase === 'failed') {
        if (journal.failurePending) await fail(journal.reason);
        return;
      }
      if (journal?.taskId === task.id && journal.phase === 'sent') {
        const record = journal;
        await acknowledgeSent();
        if (!isCurrent(record, ownEpoch) || record.phase !== 'sent') return;
        const result = await toTab('CHATMCP_BROWSER_CHECK', {}, record);
        if (!isCurrent(record, ownEpoch) || record.phase !== 'sent') return;
        if (!result?.ok || result.pageId !== journal.pageId) { await fail(result?.reason || 'tab_reloaded_or_unknown_dom'); return; }
        if (result.state === 'reply') {
          if (typeof result.text !== 'string' || !Array.isArray(result.blocks) || result.blocks.some(block => typeof block !== 'string') || typeof result.replyId !== 'string' || result.replyId.length > 256 || !safeChatUrl(result.url)) { await fail('invalid_reply_payload'); return; }
          const reply = { taskId: journal.taskId, messageId: journal.messageId, replyId: result.replyId, text: result.text, blocks: result.blocks, url: safeChatUrl(result.url) };
          if (serialSize({ ...reply, clientId: pair.clientId }) > 2 * 1024 * 1024) { await fail('reply_too_large: Câu trả lời vượt 2 MiB; không tự cắt bỏ nội dung.'); return; }
          journal.reply = reply; journal.phase = 'reply_pending'; journal.url = reply.url;
          await saveJournal();
          if (!isCurrent(record, ownEpoch) || record.phase !== 'reply_pending') return;
          await deliverReply();
        } else lastNote = result.state === 'busy' ? 'ChatGPT đang trả lời trong tab tác vụ.' : 'Đang đợi câu trả lời kết thúc và ổn định.';
        return;
      }
      if (journal?.taskId === task.id && journal.phase === 'reply_pending') { await deliverReply(); return; }
      const message = poll.message;
      if (!message) { lastNote = 'Đang chờ Hub/công cụ xử lý bước tiếp theo.'; return; }
      if (typeof message.id !== 'string' || !message.id || message.taskId !== task.id || !Number.isSafeInteger(message.turn) || message.turn < 1 || typeof message.text !== 'string' || !message.text.trim() || new TextEncoder().encode(message.text).length > 1024 * 1024) {
        // Bind the failure to this queued message, never a previous task.
        if (typeof message.id === 'string' && message.id && message.taskId === task.id) {
          journal = { taskId: task.id, messageId: message.id, phase: 'preparing', instanceId: poll.instanceId, tabId: journal?.taskId === task.id ? journal.tabId : null };
          await fail('invalid_queued_message');
        } else lastNote = 'Hub trả bước thiếu mã hợp lệ; chưa nhận/gửi yêu cầu.';
        return;
      }
      if (journal?.messageId === message.id && journal.phase !== 'preparing') return;
      await prepareAndSend(message, poll.instanceId, ownEpoch);
    } catch (error) {
      if (ownEpoch !== epoch) return;
      const reason = String(error?.message || 'bridge_error');
      if (reason === 'hub_http_401' || reason === 'hub_http_403') {
        pair.authFailed = true; await savePair().catch(() => {});
        lastNote = 'Ghép nối đã hết hiệu lực. Lấy mã mới trên Hub; không tự gửi thêm tin.';
      } else if (reason.startsWith('hub_http_4')) {
        await fail('hub_rejected_step: Hub không chấp nhận bước; không gửi lại tin nhắn.').catch(() => {});
      } else if (journal && UNCERTAIN.has(journal.phase)) {
        await fail('transport_uncertain: Mất xác nhận trong bước gửi; không tự lặp lại.').catch(() => {});
      } else {
        lastNote = 'Đang chờ kết nối Hub/tab. Không gửi lại tin đã gửi.';
        // Missing content after a confirmed send is an ambiguous page reload,
        // not a reason to inject the same prompt again.
        if (journal?.phase === 'sent' && !reason.startsWith('hub_') && !/fetch|network|abort/i.test(reason)) await fail('tab_unavailable_after_send: Không còn đọc được tab đã gửi.').catch(() => {});
      }
    } finally {
      ticking = false;
      if (pair && !pair.authFailed && active()) schedule();
    }
  }

  async function pairWithHub(code) {
    await ready();
    if (active()) throw new Error('Hãy dừng tác vụ hiện tại trên Hub trước khi ghép lại.');
    if (typeof code !== 'string' || !code.trim() || code.trim().length > 128) throw new Error('Nhập mã ghép được cấp trên Hub.');
    const ownEpoch = ++epoch;
    const clientId = pair?.clientId || crypto.randomUUID();
    const result = await api('pair', { code: code.trim(), clientId, extensionId: chrome.runtime.id }, null);
    if (ownEpoch !== epoch) throw new Error('pairing_cancelled');
    if (result?.clientId !== clientId || typeof result.token !== 'string' || result.token.length < 16 || result.token.length > 4096 || /\s/.test(result.token)) throw new Error('Hub trả kết quả ghép không hợp lệ.');
    pair = { clientId, token: result.token, authFailed: false }; journal = null;
    await savePair();
    if (ownEpoch !== epoch) throw new Error('pairing_cancelled');
    await saveJournal();
    if (ownEpoch !== epoch) throw new Error('pairing_cancelled');
    await chrome.alarms.create(ALARM, { delayInMinutes: 0.5, periodInMinutes: 0.5 });
    if (ownEpoch !== epoch) throw new Error('pairing_cancelled');
    lastNote = 'Đã ghép. Kiểm tra tab ChatGPT mở ra đang đăng nhập và ở Chat thông thường, rồi gửi yêu cầu trên Hub.';
    await chrome.tabs.create({ url: 'https://chatgpt.com/', active: true });
    if (ownEpoch !== epoch) throw new Error('pairing_cancelled');
    schedule(50);
    return publicState();
  }
  async function resetPair() {
    await ready(); epoch += 1;
    const oldPair = pair, oldJournal = journal, ownEpoch = epoch;
    pair = null; journal = null;
    clearTimeout(scheduled); scheduled = null;
    const cleanup = persist(() => chrome.storage.local.remove([PAIR_KEY, JOURNAL_KEY]));
    await chrome.alarms.clear(ALARM); await cleanup;
    if (oldJournal && !['terminal', 'failed'].includes(oldJournal.phase)) {
      try { await toTab('CHATMCP_BROWSER_CANCEL', { stopGeneration: false }, oldJournal); } catch {}
      try { await api('fail', { taskId: oldJournal.taskId, messageId: oldJournal.messageId, reason: 'pairing_reset: Người dùng ngắt ghép nối extension.' }, oldPair); } catch {}
    }
    if (ownEpoch !== epoch) return publicState();
    lastNote = 'Đã ngắt ghép. Không nhận thêm yêu cầu từ Hub.';
    return publicState();
  }
  function publicState() {
    return { paired: !!pair && !pair.authFailed, clientId: pair?.clientId || null, note: lastNote, lastContact, taskId: journal?.taskId || null, phase: journal?.phase || 'idle', chatUrl: journal?.url || null };
  }

  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (!message || sender?.id !== chrome.runtime.id) return false;
    if (ownPopup(sender) && ['CHATMCP_BROWSER_PAIR', 'CHATMCP_BROWSER_RESET', 'CHATMCP_BROWSER_STATUS'].includes(message.type)) {
      const work = message.type === 'CHATMCP_BROWSER_PAIR' ? pairWithHub(message.code) : message.type === 'CHATMCP_BROWSER_RESET' ? resetPair() : ready().then(publicState);
      work.then(state => respond({ ok: true, ...state }), () => respond({ ok: false, reason: 'Chưa thực hiện được. Kiểm tra Hub, mã ghép còn hạn và dừng tác vụ cũ nếu có.' }));
      return true;
    }
    if ((message.type === 'CHATMCP_BROWSER_WAKE' && topHub(sender)) || (message.type === 'CHATMCP_BROWSER_TICK' && topChat(sender))) {
      ready().then(() => {
        if (message.type === 'CHATMCP_BROWSER_TICK' && sender.tab.id !== journal?.tabId) return;
        schedule(0);
      }).catch(() => {});
      respond({ ok: true }); return false;
    }
    return false;
  });
  chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === ALARM) void tick(); });
  chrome.runtime.onStartup?.addListener(() => { void ready().then(() => tick()); });
  chrome.tabs.onUpdated?.addListener(tabId => { if (tabId === journal?.tabId) schedule(100); });
  chrome.tabs.onRemoved?.addListener(tabId => { if (tabId === journal?.tabId && active()) void fail('owned_tab_closed: Tab ChatGPT của tác vụ đã bị đóng.'); });
  void ready().then(() => schedule(50)).catch(() => { lastNote = 'Không đọc/lưu được ghép nối extension. Chưa nhận tác vụ.'; });
})();
