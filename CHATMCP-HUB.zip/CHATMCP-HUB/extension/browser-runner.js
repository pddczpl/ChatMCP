(() => {
  'use strict';
  if (location.origin !== 'https://chatgpt.com' || window.top !== window) return;
  const pageId = crypto.randomUUID();
  const STABLE_MS = 1800;
  const MAX_BYTES = 2 * 1024 * 1024;
  let current = null;
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const url = () => location.origin + location.pathname;
  const plain = element => element.tagName === 'TEXTAREA' ? element.value : element.innerText || element.textContent || '';
  const normalized = text => String(text).replace(/\r\n/g, '\n').replace(/\s+/g, ' ').trim();
  function visible(element) {
    if (!element || element.closest('[hidden],[aria-hidden="true"]')) return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
  function elements(selector) { return Array.from(document.querySelectorAll(selector)).filter(visible); }
  function input() {
    for (const selector of ['#prompt-textarea', '.ProseMirror[contenteditable="true"]']) {
      const matches = elements(selector).filter(element => !element.disabled && !element.readOnly && (element.tagName === 'TEXTAREA' || element.getAttribute('contenteditable') === 'true'));
      if (matches.length > 1) return { reason: 'ambiguous_composer' };
      if (matches.length === 1) return { element: matches[0] };
    }
    return { reason: 'composer_missing: Chưa thấy ô chat; kiểm tra đăng nhập và giao diện ChatGPT.' };
  }
  function sends() { return elements('button[data-testid="send-button"],button[data-testid="fruitjuice-send-button"]'); }
  function stops() { return elements('button[data-testid="stop-button"],button[aria-label="Stop generating"]'); }
  function interruption() {
    const selectedMode = elements('[role="tab"][aria-selected="true"],[role="radio"][aria-checked="true"],button[aria-pressed="true"]')
      .find(element => !element.closest('[data-message-author-role],#mcp-popover-container,#mcp-popover-portal') && /^(work|codex|agent|agent mode|chế độ tác tử|chế độ tác nhân)$/i.test(normalized(plain(element))));
    if (selectedMode) return 'wrong_chat_mode: Giao diện đang chọn Work/Codex/Agent. Hãy chọn Chat thông thường; extension không tự đổi chế độ.';
    const login = elements('a,button').find(element => !element.closest('#mcp-popover-container,.mcp-instructions-container') && /^(log in|login|sign in|đăng nhập)$/i.test(normalized(plain(element))));
    if (login) return 'login_required: Đăng nhập ChatGPT thông thường trong trình duyệt; extension không nhập tài khoản.';
    const dialogs = elements('[role="dialog"],[role="alert"]');
    for (const element of dialogs) {
      if (element.closest('#mcp-popover-container,#mcp-popover-portal')) continue;
      const text = plain(element);
      if (/usage limit|message limit|limit reached|reached.{0,35}limit|too many requests|try again later|hết.{0,25}hạn mức|đạt.{0,25}giới hạn|giới hạn.{0,25}tin nhắn/i.test(text)) return 'chatgpt_limit: ChatGPT đang báo hạn mức hoặc cần chờ. Không tự chuyển model/tài khoản hay vượt giới hạn.';
      if (element.getAttribute('role') === 'dialog') return 'dialog_requires_user: ChatGPT có hộp thoại cần người dùng xử lý; chưa bấm nút nào.';
    }
    return null;
  }
  function authored(role) {
    return elements('[data-message-author-role="' + role + '"]').filter(element => {
      if (element.closest('blockquote,textarea,script,style,[contenteditable="true"],.function-block,.function-result-container,.system-message-container,.mcp-instructions-container,#mcp-popover-container,#mcp-popover-portal')) return false;
      for (let parent = element.parentElement; parent; parent = parent.parentElement) {
        const value = parent.getAttribute('data-message-author-role');
        if (value !== null) return false; // Select one outer author node per turn.
      }
      return true;
    });
  }
  function validRoute() {
    if (!current) return true;
    if (location.pathname === current.route) return true;
    if (current.route === '/' && /^\/c\/[^/]+\/?$/.test(location.pathname)) { current.route = location.pathname; return true; }
    return false;
  }
  function ownUser() {
    if (!current) return null;
    return authored('user').findLast(element => normalized(plain(element)) === current.promptNormalized) || null;
  }
  function after(element, anchor) { return Boolean(anchor.compareDocumentPosition(element) & Node.DOCUMENT_POSITION_FOLLOWING); }
  function cleanupClone(element) {
    const clone = element.cloneNode(true);
    clone.querySelectorAll('script,style,template,textarea,input,select,button,[contenteditable="true"],[data-markdown-copy="exclude"],.function-block,.function-result-container,.system-message-container,#mcp-popover-container').forEach(child => child.remove());
    return clone;
  }
  function extractReply(author) {
    const blocks = [];
    const seen = new Set();
    const candidates = Array.from(author.querySelectorAll('pre,[data-markdown-copy="code-block"]'));
    for (const element of candidates) {
      if (candidates.some(other => other !== element && other.contains(element))) continue;
      const clone = cleanupClone(element);
      const code = clone.tagName === 'PRE' ? clone.querySelector('code') : null;
      const text = (code || clone).textContent || '';
      if (!seen.has(text)) { blocks.push(text); seen.add(text); }
    }
    const text = cleanupClone(author).textContent || '';
    if (new TextEncoder().encode(JSON.stringify({ text, blocks })).length > MAX_BYTES) return { reason: 'reply_too_large: Không cắt bớt câu trả lời vượt 2 MiB.' };
    return { text, blocks };
  }
  async function hash(text) {
    const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, '0')).join('');
  }
  function matches(message) { return current && message.taskId === current.taskId && message.messageId === current.messageId && (!message.pageId || message.pageId === pageId); }

  async function prepare(message) {
    if (typeof message.text !== 'string' || !message.text.trim() || new TextEncoder().encode(message.text).length > 1024 * 1024 || typeof message.taskId !== 'string' || typeof message.messageId !== 'string') return { ok: false, reason: 'invalid_prompt_payload' };
    if (!current && message.turn !== 1) return { ok: false, reason: 'missing_previous_turn: Tab đã tải lại hoặc thiếu ngữ cảnh của tác vụ; không gửi tiếp vào cuộc chat chưa xác minh.' };
    if (current && !matches(message) && !['reply', 'cancelled', 'failed'].includes(current.stage)) return { ok: false, reason: 'previous_turn_not_finished' };
    if (current && matches(message) && current.stage !== 'prepared') return { ok: false, reason: 'send_already_attempted' };
    if (current && !validRoute()) return { ok: false, reason: 'user_navigated_chat' };
    const blocker = interruption();
    if (blocker) return { ok: false, reason: blocker };
    if (stops().length) return { ok: false, reason: 'chat_is_busy', retryable: true };
    const found = input();
    if (!found.element) return { ok: false, reason: found.reason, retryable: true };
    const composer = found.element;
    if (!current || !matches(message)) {
      if (plain(composer).trim()) return { ok: false, reason: 'existing_user_draft: Ô chat có bản nháp; không ghi đè.' };
      if (message.turn === 1 && (authored('user').length || authored('assistant').length)) return { ok: false, reason: 'new_task_requires_empty_chat' };
      current = { taskId: message.taskId, messageId: message.messageId, turn: message.turn, stage: 'prepared', promptNormalized: normalized(message.text), text: message.text, route: location.pathname, stopSeen: false, sentAt: null, stableText: null, stableSince: 0, confirmedUser: false };
      // The new dialect is separate from the legacy JSONL bridge. This affects
      // our companion only; it never changes MCP SuperAssistant's store/toggles.
      globalThis.__chatmcpBridgeSetAuto?.(false);
      composer.focus();
      try {
        if (composer.tagName === 'TEXTAREA') {
          const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
          if (!setter) return { ok: false, reason: 'input_setter_unavailable' };
          setter.call(composer, message.text);
          composer.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          const selection = window.getSelection();
          if (!selection || typeof document.execCommand !== 'function') return { ok: false, reason: 'input_insertion_unsupported' };
          const range = document.createRange(); range.selectNodeContents(composer); range.collapse(false);
          selection.removeAllRanges(); selection.addRange(range);
          if (!document.execCommand('insertText', false, message.text)) return { ok: false, reason: 'input_insertion_unconfirmed' };
        }
      } catch { return { ok: false, reason: 'input_insertion_unsupported' }; }
    }
    if (normalized(plain(composer)) !== current.promptNormalized) return { ok: false, reason: 'draft_changed_or_insertion_unconfirmed' };
    for (let attempt = 0; attempt < 15; attempt += 1) {
      if (!matches(message) || !validRoute()) return { ok: false, reason: 'preparation_changed' };
      const buttons = sends();
      if (buttons.length > 1) return { ok: false, reason: 'ambiguous_send_button' };
      if (buttons.length === 1 && !buttons[0].disabled && buttons[0].getAttribute('aria-disabled') !== 'true') return { ok: true, pageId, url: url() };
      await sleep(100);
    }
    return { ok: false, reason: 'known_send_button_not_ready', retryable: true };
  }

  async function send(message) {
    if (!matches(message) || current.stage !== 'prepared' || !validRoute()) return { ok: false, reason: 'send_state_mismatch' };
    const blocker = interruption();
    if (blocker) return { ok: false, reason: blocker };
    const composer = input().element;
    const buttons = sends();
    if (!composer || normalized(plain(composer)) !== current.promptNormalized || stops().length || buttons.length !== 1 || buttons[0].disabled || buttons[0].getAttribute('aria-disabled') === 'true') return { ok: false, reason: 'send_preconditions_changed' };
    // No retry after this point. A disconnected response port may hide a
    // successful click, so the background journal treats it as ambiguous.
    current.stage = 'sending'; current.sentAt = Date.now();
    buttons[0].click();
    for (let attempt = 0; attempt < 150; attempt += 1) {
      if (!matches(message) || current.stage === 'cancelled') return { ok: false, reason: 'cancelled_during_send' };
      if (!validRoute()) return { ok: false, reason: 'user_navigated_chat' };
      if (stops().length) current.stopSeen = true;
      const blockerNow = interruption();
      if (blockerNow) return { ok: false, reason: blockerNow };
      const user = ownUser();
      const presentComposer = input().element;
      if (user && presentComposer && !plain(presentComposer).trim()) {
        current.confirmedUser = true; current.stage = 'sent';
        return { ok: true, pageId, url: url() };
      }
      await sleep(100);
    }
    current.stage = 'failed';
    return { ok: false, reason: 'send_unconfirmed: Không thấy tin người dùng tương ứng sau click; không gửi lại.' };
  }

  async function check(message) {
    if (!matches(message) || !['sent', 'reply'].includes(current.stage)) return { ok: false, reason: 'tab_reloaded_or_turn_missing', pageId };
    if (!validRoute()) return { ok: false, reason: 'user_navigated_chat', pageId };
    const blocker = interruption();
    if (blocker) return { ok: false, reason: blocker, pageId };
    const user = ownUser();
    if (!user) return { ok: false, reason: 'own_submitted_message_missing', pageId };
    if (authored('user').some(element => element !== user && after(element, user))) return { ok: false, reason: 'user_intervened_in_owned_chat', pageId };
    const composer = input().element;
    if (composer && plain(composer).trim()) return { ok: false, reason: 'user_draft_in_owned_chat: Dừng để không gửi nhầm bản nháp.', pageId };
    if (stops().length) { current.stopSeen = true; current.stableText = null; return { ok: true, state: 'busy', pageId }; }
    const author = authored('assistant').filter(element => after(element, user)).at(-1);
    if (!author) {
      if (Date.now() - current.sentAt > 60000) return { ok: false, reason: 'assistant_dom_not_found: Không xác minh được câu trả lời mới trên giao diện này.', pageId };
      return { ok: true, state: 'waiting', pageId };
    }
    // Known idle requires explicit aria-busy=false or a witnessed generation
    // Stop control which has disappeared. Stable text alone
    // is insufficient. Never click buttons to infer completion.
    const idle = author.getAttribute('aria-busy') === 'false' || (composer && current.stopSeen);
    if (!idle || author.getAttribute('aria-busy') === 'true') {
      if (!current.stopSeen && author.getAttribute('aria-busy') !== 'true' && Date.now() - current.sentAt > 60000) return { ok: false, reason: 'completion_state_unknown: Không xác minh được trạng thái kết thúc của giao diện.', pageId };
      return { ok: true, state: 'waiting', pageId };
    }
    const reply = extractReply(author);
    if (reply.reason) return { ok: false, reason: reply.reason, pageId };
    if (!reply.text.trim()) return { ok: true, state: 'waiting', pageId };
    const canonical = JSON.stringify(reply);
    if (canonical !== current.stableText) { current.stableText = canonical; current.stableSince = Date.now(); return { ok: true, state: 'stabilizing', pageId }; }
    if (Date.now() - current.stableSince < STABLE_MS) return { ok: true, state: 'stabilizing', pageId };
    current.stage = 'reply';
    const replyId = 'reply-' + await hash(current.messageId + '\n' + canonical);
    return { ok: true, state: 'reply', pageId, replyId, text: reply.text, blocks: reply.blocks, url: url() };
  }

  function cancel(message) {
    if (!matches(message)) return { ok: true, pageId };
    const user = ownUser();
    const ownGeneration = ['sent', 'sending'].includes(current.stage) && current.confirmedUser && validRoute() && user && !authored('user').some(element => element !== user && after(element, user));
    current.stage = 'cancelled';
    if (message.stopGeneration === true && ownGeneration) {
      const buttons = stops();
      if (buttons.length === 1) buttons[0].click();
    }
    return { ok: true, pageId };
  }

  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender?.id !== chrome.runtime.id || sender.tab || (sender.url && !sender.url.startsWith(chrome.runtime.getURL('')))) return false;
    if (!['CHATMCP_BROWSER_PREPARE', 'CHATMCP_BROWSER_SEND', 'CHATMCP_BROWSER_CHECK', 'CHATMCP_BROWSER_CANCEL'].includes(message?.type)) return false;
    const work = message.type === 'CHATMCP_BROWSER_PREPARE' ? prepare(message) : message.type === 'CHATMCP_BROWSER_SEND' ? send(message) : message.type === 'CHATMCP_BROWSER_CHECK' ? check(message) : Promise.resolve(cancel(message));
    work.then(respond, () => respond({ ok: false, reason: 'browser_dom_operation_failed', pageId }));
    return true;
  });
  setInterval(() => {
    if (current && ['prepared', 'sending', 'sent', 'reply'].includes(current.stage)) {
      if (stops().length) current.stopSeen = true;
      chrome.runtime.sendMessage({ type: 'CHATMCP_BROWSER_TICK' }).catch(() => {});
    }
  }, 1500);
})();
